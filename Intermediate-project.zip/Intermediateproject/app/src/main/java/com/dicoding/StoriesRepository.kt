package com.dicoding

import androidx.lifecycle.LiveData
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.dicoding.api.Dicoding
import com.dicoding.api.Story
import com.dicoding.helper.StoryPagerAdapter

class StoriesRepository(private val apiService: Dicoding, private val header: Map<String, String>) {
    fun getAllStory(): LiveData<PagingData<Story>> {
        return Pager(
            config = PagingConfig(
                pageSize = 15
            ),
            pagingSourceFactory = {
                StoryPagerAdapter(apiService, header)
            }
        ).liveData
    }
}