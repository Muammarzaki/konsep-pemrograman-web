package com.dicoding

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.dicoding.databinding.ActivityDetailStoryBinding
import com.dicoding.model.DetailViewModel

class DetailStory : AppCompatActivity() {
    private val viewModel: DetailViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityDetailStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        intent.getStringExtra("image")?.let {
            viewModel.setImage(Uri.parse(it))
        }
        intent.getStringExtra("name")?.let {
            viewModel.setName(it)
        }
        intent.getStringExtra("desc")?.let {
            viewModel.setDesc(it)
        }

        intent.getDoubleExtra("lat", 0.0)
            .let { lat ->
                intent.getDoubleExtra("lon", 0.0)
                    .let { lon ->
                        viewModel.setLat(Pair(lat, lon))
                    }
            }

        viewModel.desc.observe(this) {
            binding.tvDetailDescription.text = it
        }
        viewModel.name.observe(this) {
            binding.tvDetailName.text = it
        }
        viewModel.image.observe(this) {
            Glide.with(this)
                .load(it)
                .centerInside()
                .into(binding.ivDetailPhoto)
        }

        binding.locate.setOnClickListener {
            val intent = Intent(this, MapsActivity::class.java)
            intent.putExtra("sourceActivity", "DetailStory")
            intent.putExtra("lat", viewModel.lat.value?.first)
            intent.putExtra("lon", viewModel.lat.value?.second)
            startActivity(intent)
        }
    }
}