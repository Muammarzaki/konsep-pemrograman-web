package com.dicoding.api

import com.google.gson.annotations.SerializedName

data class UserRegistration(
    @field:SerializedName("name")
    val name: String,
    @field:SerializedName("email")
    val email: String,
    @field:SerializedName("password")
    val password: String
)