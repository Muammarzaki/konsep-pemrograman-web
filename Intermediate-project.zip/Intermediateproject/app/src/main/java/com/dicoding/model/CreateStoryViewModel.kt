package com.dicoding.model

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class CreateStoryViewModel : ViewModel() {
    private var _desc = MutableLiveData<String>()
    val desc: LiveData<String> = _desc

    fun setDesc(str: String) {
        _desc.value = str
    }

    private var _image = MutableLiveData<Uri?>()
    val image: LiveData<Uri?> = _image

    fun setImage(str: Uri?) {
        _image.value = str
    }
}