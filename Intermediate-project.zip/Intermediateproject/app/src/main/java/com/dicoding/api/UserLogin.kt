package com.dicoding.api

import com.google.gson.annotations.SerializedName

data class UserLogin(
    @field:SerializedName("email")
    val email: String,
    @field:SerializedName("password")
    val password: String
)