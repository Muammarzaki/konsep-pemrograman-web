package com.dicoding.model

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class DetailViewModel : ViewModel() {
    private var _image = MutableLiveData<Uri>()
    val image: LiveData<Uri> = _image

    fun setImage(uri: Uri) {
        _image.value = uri
    }

    private var _name = MutableLiveData<String>()
    val name: LiveData<String> = _name

    fun setName(uri: String) {
        _name.value = uri
    }

    private var _desc = MutableLiveData<String>()
    val desc: LiveData<String> = _desc

    fun setDesc(uri: String) {
        _desc.value = uri
    }

    private var _lat = MutableLiveData<Pair<Double, Double>>()
    val lat: MutableLiveData<Pair<Double, Double>> = _lat

    fun setLat(it: Pair<Double, Double>) {
        _lat.value = it
    }


}