package com.dicoding

import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import com.dicoding.api.DicodingClient
import com.dicoding.api.Response
import com.dicoding.databinding.ActivityCreateStoryBinding
import com.dicoding.model.CreateStoryViewModel
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CreateStoryActivity : AppCompatActivity() {
    private lateinit var header: Map<String, String>
    private lateinit var binding: ActivityCreateStoryBinding
    private lateinit var registerForActivityResultCameraIntent: ActivityResultLauncher<Uri>
    private var currentImageUri: Uri? = null
    private val viewModel: CreateStoryViewModel by viewModels()

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        binding = ActivityCreateStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val preference = getSharedPreferences("login", MODE_PRIVATE)
        header = mapOf(
            "Authorization" to "Bearer ${preference.getString("token", "")}"
        )
        registerForActivityResultCameraIntent =
            registerForActivityResult(
                ActivityResultContracts.TakePicture()
            ) { isSuccess ->
                if (isSuccess) {
                    viewModel.setImage(currentImageUri)
                } else {
                    viewModel.setImage(null)
                }
            }
        val registerForActivityResultImage =
            registerForActivityResult(ActivityResultContracts.PickVisualMedia()) {
                it?.let { it1 -> viewModel.setImage(it1) }
            }

        viewModel.image.observe(this) {
            currentImageUri = it
            binding.imageView.setImageURI(it)
        }

        viewModel.desc.observe(this) {
            binding.edAddDescription.setText(it)
        }

        binding.button3.setOnClickListener {
            startCamera()
        }
        binding.button2.setOnClickListener {
            registerForActivityResultImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }

        binding.buttonAdd.setOnClickListener {
            uploadImage()
        }
    }

    private fun getCurrentLocation(onLocationReceived: (Double, Double) -> Unit) {
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                1001
            )
            return
        }

        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            if (location != null) {
                onLocationReceived(location.latitude, location.longitude)
            } else {
                Toast.makeText(this, "Unable to retrieve location", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun File.reduceFileImage(): File {
        val file = this
        val bitmap = BitmapFactory.decodeFile(file.path)
        var compressQuality = 100
        var streamLength: Int
        do {
            val bmpStream = ByteArrayOutputStream()
            bitmap?.compress(Bitmap.CompressFormat.JPEG, compressQuality, bmpStream)
            val bmpPicByteArray = bmpStream.toByteArray()
            streamLength = bmpPicByteArray.size
            compressQuality -= 5
        } while (streamLength > MAXIMAL_SIZE)
        bitmap?.compress(Bitmap.CompressFormat.JPEG, compressQuality, FileOutputStream(file))
        return file
    }

    private fun createCustomTempFile(): File {
        val filesDir = this.externalCacheDir
        return File.createTempFile(timeStamp, ".jpg", filesDir)
    }

    private fun uploadImage() {
        getCurrentLocation { lat, lon ->
            currentImageUri?.let { uri ->
                val imageFile = uriToFile(uri).reduceFileImage()
                Log.d("Image File", "showImage: ${imageFile.path}")
                val multipartBody = MultipartBody.Part.createFormData(
                    "photo",
                    imageFile.name,
                    RequestBody.create(MediaType.get("image/jpeg"), imageFile)
                )

                val desc = binding.edAddDescription.text.toString()
                if (desc.isEmpty()) {
                    Toast.makeText(this, "Description cannot be empty", Toast.LENGTH_SHORT).show()
                    return@getCurrentLocation
                }

                DicodingClient.service.addNewStory(
                    header,
                    multipartBody,
                    RequestBody.create(MediaType.parse("text/plain"), desc),
                    lat,
                    lon,
                ).enqueue(object : Callback<Response> {
                    override fun onResponse(p0: Call<Response>, p1: retrofit2.Response<Response>) {
                        if (p1.isSuccessful) {
                            startActivity(
                                Intent(
                                    this@CreateStoryActivity,
                                    MainActivity::class.java
                                )
                            )
                        } else {
                            Toast.makeText(this@CreateStoryActivity, "Fail", Toast.LENGTH_SHORT)
                                .show()
                        }
                    }

                    override fun onFailure(p0: Call<Response>, p1: Throwable) = Unit
                })
            } ?: run {
                Toast.makeText(this, "Image not found", Toast.LENGTH_SHORT).show()
                return@getCurrentLocation
            }
        }
    }

    private fun uriToFile(imageUri: Uri): File {
        val myFile = createCustomTempFile()
        val inputStream = this.contentResolver.openInputStream(imageUri) as InputStream
        val outputStream = FileOutputStream(myFile)
        val buffer = ByteArray(1024)
        var length: Int
        while (inputStream.read(buffer).also { length = it } > 0) outputStream.write(
            buffer,
            0,
            length
        )
        outputStream.close()
        inputStream.close()
        return myFile
    }

    companion object {
        private const val FILENAME_FORMAT = "yyyyMMdd_HHmmss"
        private const val MAXIMAL_SIZE = 1000000
    }

    private fun startCamera() {
        currentImageUri = getImageUri()
        currentImageUri?.let {
            registerForActivityResultCameraIntent.launch(it)
        }
    }

    private val timeStamp: String =
        SimpleDateFormat(FILENAME_FORMAT, Locale.getDefault()).format(Date())

    private fun getImageUri(): Uri {
        var uri: Uri? = null
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$timeStamp.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/MyCamera/")
        }
        uri = this.contentResolver.insert(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            contentValues
        )
        return uri ?: getImageUriForPreQ()
    }

    private fun getImageUriForPreQ(): Uri {
        val filesDir = this.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        val imageFile = File(filesDir, "/MyCamera/$timeStamp.jpg")
        if (imageFile.parentFile?.exists() == false) imageFile.parentFile?.mkdir()
        return FileProvider.getUriForFile(
            this,
            "${BuildConfig.APPLICATION_ID}.fileprovider",
            imageFile
        )
    }
}