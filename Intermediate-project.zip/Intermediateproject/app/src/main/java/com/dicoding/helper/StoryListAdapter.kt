package com.dicoding.helper

import android.app.Activity
import android.app.ActivityOptions
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.DetailStory
import com.dicoding.api.Story
import com.dicoding.databinding.StoryCardBinding

class StoryListAdapter : PagingDataAdapter<Story, StoryListAdapter.ViewHolder>(Story.DIFF_UTIL) {

    class ViewHolder(private val binding: StoryCardBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: Story) {

            binding.tvItemName.text = item.name
            Glide.with(binding.root.context)
                .load(item.photoUrl)
                .centerInside()
                .into(binding.ivItemPhoto)

            binding.root.setOnClickListener {
                val intent = Intent(binding.root.context, DetailStory::class.java)
                intent.putExtra("image", item.photoUrl.toString())
                intent.putExtra("name", item.name)
                intent.putExtra("desc", item.description)
                intent.putExtra("lat", item.lat)
                intent.putExtra("lon", item.lon)

                binding.root.context.startActivity(
                    intent,
                    ActivityOptions.makeSceneTransitionAnimation(
                        binding.root.context as Activity,
                        android.util.Pair(binding.ivItemPhoto, "image")
                    )
                        .toBundle()
                )
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = StoryCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        getItem(position)?.let {
            holder.bind(it)
        }
    }
}