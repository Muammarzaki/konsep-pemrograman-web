package com.dicoding.api

import com.google.gson.annotations.SerializedName

data class Response(

    @field:SerializedName("error")
    val error: Boolean? = null,

    @field:SerializedName("message")
    val message: String? = null,

    @field:SerializedName("story")
    val story: Story? = null,

    @field:SerializedName("loginResult")
    val loginResult: LoginResult? = null,

    @field:SerializedName("listStory")
    val listStory: List<Story> = emptyList()
)