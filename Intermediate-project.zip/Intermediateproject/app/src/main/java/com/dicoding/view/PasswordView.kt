package com.dicoding.view

import android.content.Context
import android.text.InputType
import android.util.AttributeSet
import com.google.android.material.textfield.TextInputEditText

class PasswordView : TextInputEditText {
    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)

    init {
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    override fun onTextChanged(
        text: CharSequence?, start: Int, before: Int, count: Int
    ) {
        super.onTextChanged(text, start, before, count)

        error = if ((text?.length ?: 0) < 8 && !text.isNullOrEmpty()) {
            "Password minimal 8 karakter"
        } else {
            null
        }
    }
}