package com.dicoding

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.dicoding.api.DicodingClient
import com.dicoding.api.Response
import com.dicoding.databinding.ActivityLoginBinding
import retrofit2.Call
import retrofit2.Callback

class LoginActivity : AppCompatActivity() {
    private lateinit var preference: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityLoginBinding.inflate(layoutInflater)
        var intent: Intent?
        preference = getSharedPreferences("login", Context.MODE_PRIVATE)
        val token = preference.getString("token", "")
        if (!token.isNullOrEmpty()) {
            intent = Intent(this@LoginActivity, MainActivity::class.java)
            startActivity(intent)
        } else {
            setContentView(binding.root)
        }
        binding.button.setOnClickListener {
            DicodingClient.service.loginUser(
                binding.edLoginEmail.text.toString(),
                binding.edLoginPassword.text.toString()
            )
                .enqueue(object : Callback<Response> {
                    override fun onResponse(
                        p0: Call<Response>,
                        p1: retrofit2.Response<Response>
                    ) {
                        if (p1.isSuccessful) {
                            p1.body()?.loginResult?.let {
                                val edit = preference.edit()
                                edit.putString("token", it.token)
                                edit.putString("username", it.name)
                                edit.putString("user_id", it.userId)
                                edit.commit()
                            }
                            intent = Intent(this@LoginActivity, MainActivity::class.java)
                            startActivity(intent)
                        }

                        if (p1.code() == 401) {
                            binding.edLoginEmail.error = "Email Invalid"
                        }

                    }

                    override fun onFailure(p0: Call<Response>, p1: Throwable) = Unit
                })
        }

        binding.button2.setOnClickListener {
            intent = Intent(this@LoginActivity, RegisterActivity::class.java)
            startActivity(intent)
        }
    }
}