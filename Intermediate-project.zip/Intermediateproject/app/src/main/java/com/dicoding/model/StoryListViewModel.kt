package com.dicoding.model

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.dicoding.StoriesRepository
import com.dicoding.api.Dicoding
import com.dicoding.api.Story

class StoryListViewModel(
    repository: StoriesRepository,
) : ViewModel() {


    val stories: LiveData<PagingData<Story>> =
        repository.getAllStory()
            .cachedIn(viewModelScope)

    class Factory(
        private val headerProvider: Map<String, String>,
        private val apiService: Dicoding
    ) : ViewModelProvider.Factory {

        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(StoryListViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return StoryListViewModel(StoriesRepository(apiService, headerProvider)) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}