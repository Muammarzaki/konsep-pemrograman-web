package com.dicoding

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.api.DicodingClient
import com.dicoding.databinding.ActivityMainBinding
import com.dicoding.helper.StoryListAdapter
import com.dicoding.model.StoryListViewModel

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val adapter = StoryListAdapter()
        binding.recyclerView.adapter = adapter
        binding.recyclerView.layoutManager = LinearLayoutManager(this)

        val preference = getSharedPreferences("login", MODE_PRIVATE)
        val header = mapOf(
            "Authorization" to "Bearer ${preference.getString("token", "")}"
        )
        var viewmodelFactory = StoryListViewModel.Factory(header, DicodingClient.service)
        val viewmodel: StoryListViewModel by viewModels { viewmodelFactory }

        binding.imageView2.setOnClickListener {
            val edit = preference.edit()
            edit.clear()
            edit.apply()
            startActivity(Intent(this@MainActivity, LoginActivity::class.java))
        }
        binding.imageView3.setOnClickListener {
            startActivity(Intent(this@MainActivity, CreateStoryActivity::class.java))
        }

        binding.imageView4.setOnClickListener {
            startActivity(Intent(this@MainActivity, MapsActivity::class.java))
        }

        viewmodel.stories.observe(this) {
            adapter.submitData(lifecycle, it)
        }

    }
}