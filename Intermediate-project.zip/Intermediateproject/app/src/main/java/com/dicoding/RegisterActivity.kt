package com.dicoding

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.dicoding.api.DicodingClient
import com.dicoding.api.Response
import com.dicoding.databinding.ActivityRegisterBinding
import retrofit2.Call
import retrofit2.Callback

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button.setOnClickListener {

            DicodingClient.service.registerUser(
                binding.edRegisterName.text.toString(),
                binding.edRegisterEmail.text.toString(),
                binding.edRegisterPassword.text.toString(),
            ).enqueue(
                object : Callback<Response> {
                    override fun onResponse(p0: Call<Response>, p1: retrofit2.Response<Response>) {
                        if (p1.isSuccessful) {
                            finish()
                        }
                        binding.edRegisterEmail.error = "Email exits"
                    }

                    override fun onFailure(p0: Call<Response>, p1: Throwable) = Unit

                }
            )
        }
    }
}