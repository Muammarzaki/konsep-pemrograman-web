package com.dicoding

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.dicoding.api.DicodingClient
import com.dicoding.databinding.ActivityMapsBinding
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isIndoorLevelPickerEnabled = true
        mMap.uiSettings.isCompassEnabled = true
        mMap.uiSettings.isMapToolbarEnabled = true

        val sourceActivity = intent.getStringExtra("sourceActivity")
        if (sourceActivity == "DetailStory") {
            val lon = intent.getDoubleExtra("lon", 0.0)
            val lat = intent.getDoubleExtra("lat", 0.0)

            val sydney = LatLng(lat, lon)
            mMap.addMarker(MarkerOptions().position(sydney).title("Sender Location"))
            mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney))
            return
        }

        val preference = getSharedPreferences("login", MODE_PRIVATE)
        val header = mapOf(
            "Authorization" to "Bearer ${preference.getString("token", "")}"
        )
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                try {
                    val allActiveLocationStories =
                        DicodingClient.service.getAllActiveLocationStories(headers = header)

                    withContext(Dispatchers.Main) {
                        allActiveLocationStories.listStory.forEach {
                            val latLng =
                                it.lon?.let { it1 -> it.lat?.let { it2 -> LatLng(it2, it1) } }
                            latLng?.let { it1 -> MarkerOptions().position(it1).title(it.name) }
                                ?.let { it2 -> mMap.addMarker(it2) }
                        }
                        mMap.moveCamera(
                            CameraUpdateFactory.newLatLng(
                                allActiveLocationStories.listStory.first()
                                    .run { LatLng(lat!!, lon!!) })
                        )
                    }
                } catch (e: Exception) {
                    Toast.makeText(this@MapsActivity, e.message, Toast.LENGTH_SHORT).show()
                }
            }
        }

    }
}