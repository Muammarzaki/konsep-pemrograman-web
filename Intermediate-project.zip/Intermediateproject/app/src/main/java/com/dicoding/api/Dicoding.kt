package com.dicoding.api

import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.HeaderMap
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query


interface Dicoding {
    @FormUrlEncoded
    @POST("register")
    fun registerUser(
        @Field("name") name: String,
        @Field("email") email: String,
        @Field("password") password: String
    ): Call<Response>

    @FormUrlEncoded
    @POST("login")
    fun loginUser(
        @Field("email") email: String,
        @Field("password") password: String
    ): Call<Response>

    @POST("stories")
    @Multipart
    fun addNewStory(
        @HeaderMap headers: Map<String, String>,
        @Part photo: MultipartBody.Part?,
        @Part("description") description: RequestBody?,
        @Part("lat") lat: Double? = 0.0,
        @Part("lon") lon: Double? = 0.0
    ): Call<Response>

    @POST("stories/guest")
    @Multipart
    fun addNewStoryGuest(
        @Part photo: MultipartBody.Part?,
        @Part("description") description: String?,
        @Part("lat") lat: Double?,
        @Part("lon") lon: Double?
    ): Call<Response>

    @GET("stories")
    suspend fun getAllStories(
        @Query("page") page: Int = 1,
        @Query("size") size: Int = 1,
        @HeaderMap headers: Map<String, String>
    ): Response

    @GET("stories")
    suspend fun getAllActiveLocationStories(
        @Query("location") location: Int = 1,
        @HeaderMap headers: Map<String, String>
    ): Response

    @GET("stories/{id}")
    fun getStoryDetail(@Path("id") storyId: String?): Call<Response>
}

object DicodingClient {
    val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
        .build()

    private var retrofit: Retrofit = Retrofit.Builder()
        .baseUrl("https://story-api.dicoding.dev/v1/")
        .addConverterFactory(GsonConverterFactory.create())
        .client(okHttpClient)
        .build()

    var service: Dicoding = retrofit.create(Dicoding::class.java)
}