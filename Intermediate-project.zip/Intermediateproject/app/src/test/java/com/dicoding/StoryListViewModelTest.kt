package com.dicoding

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.paging.AsyncPagingDataDiffer
import androidx.paging.PagingData
import androidx.paging.PagingSource
import androidx.paging.PagingState
import androidx.recyclerview.widget.ListUpdateCallback
import com.dicoding.api.Story
import com.dicoding.model.StoryListViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TestRule
import org.junit.runner.Description
import org.junit.runners.model.Statement
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.MockitoAnnotations

@ExperimentalCoroutinesApi
class StoryListViewModelTest {

    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    @get:Rule
    val mainDispatcherRules = MainDispatcherRule()

    private val testDispatcher = StandardTestDispatcher()

    @Mock
    private lateinit var repository: StoriesRepository
    private lateinit var viewModel: StoryListViewModel


    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
    }

    @Test
    fun `when getStory should load the story list`() = runTest {
        val dataDummy = Dummy.provideResultList()
        val expectedStories = MutableLiveData<PagingData<Story>>()
        val pagingData = StoryPagingSource.snapshot(dataDummy)

        expectedStories.value = pagingData

        `when`(repository.getAllStory())
            .thenReturn(expectedStories)

        viewModel = StoryListViewModel(repository)

        val actualStories = viewModel.stories.getOrAwaitValue()
        assertNotNull(actualStories)

        val differ = AsyncPagingDataDiffer(
            diffCallback = Story.DIFF_UTIL,
            updateCallback = noopListUpdateCallback,
            workerDispatcher = Dispatchers.Main,
        )

        differ.submitData(actualStories)

        assertNotNull(differ.snapshot().items)

        assertEquals(dataDummy.size, differ.snapshot().size)
        assertEquals(dataDummy.first(), differ.snapshot().first())
        assertEquals(dataDummy, differ.snapshot().items)
    }

    @Test
    fun `when getStory should load the story list but empty`() = runTest {
        val dataDummy = emptyList<Story>()
        val expectedStories = MutableLiveData<PagingData<Story>>()
        val pagingData = StoryPagingSource.snapshot(dataDummy)

        expectedStories.value = pagingData

        `when`(repository.getAllStory())
            .thenReturn(expectedStories)

        viewModel = StoryListViewModel(repository)

        val actualStories = viewModel.stories.getOrAwaitValue()
        assertNotNull(actualStories)

        val differ = AsyncPagingDataDiffer(
            diffCallback = Story.DIFF_UTIL,
            updateCallback = noopListUpdateCallback,
            workerDispatcher = Dispatchers.Main,
        )

        differ.submitData(actualStories)

        assertNotNull(differ.snapshot().items)
        assertEquals(0, differ.snapshot().size)
    }


    class StoryPagingSource : PagingSource<Int, LiveData<List<Story>>>() {
        companion object {
            fun snapshot(items: List<Story>): PagingData<Story> {
                return PagingData.from(items)
            }
        }

        override fun getRefreshKey(state: PagingState<Int, LiveData<List<Story>>>): Int {
            return 0
        }

        override suspend fun load(params: LoadParams<Int>): LoadResult<Int, LiveData<List<Story>>> {
            return LoadResult.Page(emptyList(), 0, 1)
        }
    }

    val noopListUpdateCallback = object : ListUpdateCallback {
        override fun onInserted(position: Int, count: Int) {}
        override fun onRemoved(position: Int, count: Int) {}
        override fun onMoved(fromPosition: Int, toPosition: Int) {}
        override fun onChanged(position: Int, count: Int, payload: Any?) {}
    }

    @ExperimentalCoroutinesApi
    class MainDispatcherRule : TestRule {
        override fun apply(base: Statement?, description: Description?) = object : Statement() {
            @Throws(Throwable::class)
            override fun evaluate() {
                Dispatchers.setMain(Dispatchers.Unconfined) // Use Unconfined for non-blocking execution
                try {
                    base?.evaluate()
                } finally {
                    Dispatchers.resetMain() // Reset the dispatcher after the test
                }
            }
        }
    }
}