package com.dicoding

import androidx.annotation.VisibleForTesting
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import com.dicoding.api.Story
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

@VisibleForTesting(otherwise = VisibleForTesting.NONE)
fun <T> LiveData<T>.getOrAwaitValue(
    time: Long = 2,
    timeUnit: TimeUnit = TimeUnit.SECONDS,
    afterObserve: () -> Unit = {}
): T {
    var data: T? = null
    val latch = CountDownLatch(1)
    val observer = object : Observer<T> {
        override fun onChanged(o: T) {
            data = o
            latch.countDown()
            this@getOrAwaitValue.removeObserver(this)
        }
    }
    this.observeForever(observer)
    try {
        afterObserve.invoke()
        if (!latch.await(time, timeUnit)) {
            throw TimeoutException("LiveData value was never set.")
        }
    } finally {
        this.removeObserver(observer)
    }
    @Suppress("UNCHECKED_CAST")
    return data as T
}


suspend fun <T> LiveData<T>.observeForTesting(block: suspend () -> Unit) {
    val observer = Observer<T> { }
    try {
        observeForever(observer)
        block()
    } finally {
        removeObserver(observer)
    }
}

object Dummy {
    fun provideResultList(): List<Story> {
        return listOf(
            Story(
                photoUrl = "https://example.com/photo1.jpg",
                createdAt = "2024-12-01T08:00:00Z",
                name = "John Doe",
                description = "This is the first story.",
                id = "1",
                lat = -6.200000,
                lon = 106.816666
            ),
            Story(
                photoUrl = "https://example.com/photo2.jpg",
                createdAt = "2024-12-02T09:00:00Z",
                name = "Jane Smith",
                description = "This is the second story.",
                id = "2",
                lat = -7.250445,
                lon = 112.768845
            ),
            Story(
                photoUrl = "https://example.com/photo3.jpg",
                createdAt = "2024-12-03T10:00:00Z",
                name = "Alice Brown",
                description = "This is the third story.",
                id = "3",
                lat = -8.340539,
                lon = 115.092093
            ),
            Story(
                photoUrl = "https://example.com/photo4.jpg",
                createdAt = "2024-12-04T11:00:00Z",
                name = "Bob White",
                description = "This is the fourth story.",
                id = "4",
                lat = -0.789275,
                lon = 113.921327
            ),
            Story(
                photoUrl = "https://example.com/photo5.jpg",
                createdAt = "2024-12-05T12:00:00Z",
                name = "Chris Green",
                description = "This is the fifth story.",
                id = "5",
                lat = -2.548926,
                lon = 118.014863
            ),
            Story(
                photoUrl = "https://example.com/photo6.jpg",
                createdAt = "2024-12-06T13:00:00Z",
                name = "Dana Black",
                description = "This is the sixth story.",
                id = "6",
                lat = -3.333333,
                lon = 114.733334
            ),
            Story(
                photoUrl = "https://example.com/photo10.jpg",
                createdAt = "2024-12-10T17:00:00Z",
                name = "Hank Yellow",
                description = "This is the tenth story.",
                id = "10",
                lat = -7.005145,
                lon = 110.438125
            )
        )
    }
}